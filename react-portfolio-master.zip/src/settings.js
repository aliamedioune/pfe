var cons={
    "link":"http://localhost/web/api/"
}
export default cons;