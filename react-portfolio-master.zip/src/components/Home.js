import React, { Component } from 'react';
import Button from 'react-bootstrap/Button'
import ToggleButtonGroup from 'react-bootstrap/ToggleButtonGroup'
import { Redirect } from 'react-router-dom';
import {  FormGroup, FormControl, ControlLabel  } from "react-bootstrap";
import "./Home.css";
import { Grid, Cell  } from 'react-mdl';
class Home extends Component {
    constructor(props) {
        super(props);
        this.state = { activeTab: 0 };
    }
   
    
    toggleCategories() {

        if (this.state.activeTab === 0) {
            return (
                <div className="container">
                <p> </p>
                    <Button  class="btn btn-primary" variant="primary" size="lg" block onclick="window.location.href='b.php';">
                      Ajouter Un Etudiant  
                      </Button>
                      <p> </p>
                    <Button variant="success" size="lg" block>
                      Ajouter Absence 
                    </Button>
                    <p> </p>
                    <Button variant="info" size="lg" block>
                       Liste Des Absence  
                    </Button>
      
}
                </div>


            )
        }

    }


    render() {
        return (
            <div>
                <p>{}</p>
               
                <Grid>
                    <Cell col={12}>
                        <div className="wrapper">{this.toggleCategories()}</div>
                    </Cell>
                </Grid>


            </div>
        )
    }
}


export default Home;
