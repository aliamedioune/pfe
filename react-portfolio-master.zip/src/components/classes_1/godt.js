import React, { Component } from 'react';


class godt extends Component {
    constructor(props) {
        super(props);
        this.state = { activeTab: 0 };
    }
    render() {
        return (
            <div>
               
            </div>
        )
    }
}


export default godt;
